# My Portal — Final Android Version

Personal Android app for saving important links and projects.

## Included
- Home dashboard
- My Links with custom pictures
- Add / Edit / Delete links
- One-tap opening of the saved original URL
- My Projects with custom pictures
- Add / Edit / Delete projects
- Project detail view
- Search
- Dark/light theme switch
- Local-only DataStore storage
- JSON backup/export
- JSON restore/import
- Clear all data confirmation
- Material 3 Jetpack Compose UI

## Run
Open this folder in Android Studio, let Gradle sync, then run the `app` configuration on an Android 8.0+ device/emulator.

## Important
This project is designed as a personal/local app. No login, cloud database, analytics, or remote server is included.
