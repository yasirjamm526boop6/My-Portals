package com.yasir.myportal.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.yasir.myportal.*

private enum class Screen { HOME, PROJECTS, LINKS, SETTINGS }

@Composable
fun MyPortalApp(vm: PortalViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    var screen by remember { mutableStateOf(Screen.HOME) }
    var addLink by remember { mutableStateOf(false) }
    var addProject by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavItem("Home", Icons.Default.Home, screen == Screen.HOME) { screen = Screen.HOME }
                NavItem("Projects", Icons.Default.Folder, screen == Screen.PROJECTS) { screen = Screen.PROJECTS }
                NavItem("Links", Icons.Default.Link, screen == Screen.LINKS) { screen = Screen.LINKS }
                NavItem("Settings", Icons.Default.Settings, screen == Screen.SETTINGS) { screen = Screen.SETTINGS }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (screen) {
                Screen.HOME -> HomeScreen(data, { screen = Screen.PROJECTS }, { screen = Screen.LINKS }, { addLink = true }, { addProject = true })
                Screen.PROJECTS -> ProjectsScreen(data.projects, vm) { addProject = true }
                Screen.LINKS -> LinksScreen(data.links, vm) { addLink = true }
                Screen.SETTINGS -> SettingsScreen(data, vm)
            }
        }
    }

    if (addLink) LinkEditorDialog(null, vm) { addLink = false }
    if (addProject) ProjectEditorDialog(null, vm) { addProject = false }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, null) }, label = { Text(label) })
}

@Composable
private fun HomeScreen(data: PortalData, projects: () -> Unit, links: () -> Unit, addLink: () -> Unit, addProject: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF0E3156), Color(0xFF12294B))))
                    .padding(22.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MY PORTAL", color = Color(0xFF70B7FF), fontWeight = FontWeight.Bold)
                    Text("Welcome Back 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Your personal space for important links and projects.", color = Color.LightGray)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeCard("My Projects", Icons.Default.Folder, data.projects.size, Color(0xFF1976D2), Modifier.weight(1f), projects)
                HomeCard("My Links", Icons.Default.Link, data.links.size, Color(0xFF00966E), Modifier.weight(1f), links)
            }
        }
        item { Text("Quick Access", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(addLink, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.AddLink, null); Spacer(Modifier.width(5.dp)); Text("Add Link")
                }
                OutlinedButton(addProject, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.CreateNewFolder, null); Spacer(Modifier.width(5.dp)); Text("Add Project")
                }
            }
        }
        item { Text("🔒 Your saved data stays on this device.", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun HomeCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, count: Int, color: Color, modifier: Modifier, click: () -> Unit) {
    Card(modifier.clickable(click), colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, Modifier.size(30.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text("$count saved", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ProjectsScreen(projects: List<Project>, vm: PortalViewModel, add: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Project?>(null) }
    val filtered = projects.filter { it.name.contains(query, true) || it.description.contains(query, true) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("My Projects", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(add) { Icon(Icons.Default.Add, "Add Project") }
        }
        SearchField(query, { query = it }, "Search projects...")
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { p ->
                Card(
                    Modifier.fillMaxWidth().clickable { selected = p },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        SavedImage(p.imageUri, 52.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(p.description.ifBlank { "No description" }, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.LightGray)
                        }
                    }
                }
            }
        }
    }
    selected?.let { ProjectDetailsDialog(it, vm) { selected = null } }
}

@Composable
private fun LinksScreen(links: List<PortalLink>, vm: PortalViewModel, add: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<PortalLink?>(null) }
    val filtered = links.filter { it.name.contains(query, true) || it.url.contains(query, true) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("My Links", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(add) { Icon(Icons.Default.Add, "Add Link") }
        }
        SearchField(query, { query = it }, "Search links...")
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.id }) { link ->
                Card(
                    Modifier.fillMaxWidth().clickable {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link.url))) }
                    },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        SavedImage(link.imageUri, 58.dp)
                        Spacer(Modifier.height(8.dp))
                        Text(link.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(link.category, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Spacer(Modifier.height(5.dp))
                        Text("Tap to open", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(link.url, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray)
                    }
                }
            }
        }
    }
    editing?.let { LinkEditorDialog(it, vm) { editing = null } }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value, onChange, Modifier.fillMaxWidth(),
        placeholder = { Text(hint) },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun SavedImage(uri: String, size: androidx.compose.ui.unit.Dp) {
    if (uri.isNotBlank()) {
        AsyncImage(model = uri, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer), Alignment.Center) {
            Icon(Icons.Default.Public, null, Modifier.size(size * .52f), tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun ImagePickerButton(currentUri: String, onPicked: (String) -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            onPicked(uri.toString())
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(86.dp).clip(CircleShape).clickable { launcher.launch(arrayOf("image/*")) }, Alignment.Center) {
            if (currentUri.isNotBlank()) {
                AsyncImage(model = currentUri, contentDescription = "Selected image", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    Box(Modifier.fillMaxSize(), Alignment.Center) { Icon(Icons.Default.AddPhotoAlternate, null, Modifier.size(34.dp)) }
                }
            }
        }
        Text(if (currentUri.isBlank()) "Choose picture" else "Change picture", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun LinkEditorDialog(existing: PortalLink?, vm: PortalViewModel, close: () -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var url by remember { mutableStateOf(existing?.url ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "Other") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var image by remember { mutableStateOf(existing?.imageUri ?: "") }
    var showDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (existing == null) "Add Link" else "Edit Link") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                ImagePickerButton(image) { image = it }
                OutlinedTextField(name, { name = it }, label = { Text("Link name") }, singleLine = true)
                OutlinedTextField(url, { url = it }, label = { Text("Website URL") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Category") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Description (optional)") })
                if (existing != null) TextButton({ showDelete = true }) { Text("Delete this link", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && url.isNotBlank()) {
                    if (existing == null) vm.addLink(name, url, category, description, image)
                    else vm.updateLink(existing.copy(name = name, url = url, category = category, description = description, imageUri = image))
                    close()
                }
            }) { Text(if (existing == null) "Save" else "Update") }
        },
        dismissButton = { TextButton(close) { Text("Cancel") } }
    )
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete link?") },
            text = { Text("This saved link will be removed from My Portal.") },
            confirmButton = { TextButton({ vm.deleteLink(existing!!.id); close() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ showDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProjectEditorDialog(existing: Project?, vm: PortalViewModel, close: () -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var link by remember { mutableStateOf(existing?.link ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var image by remember { mutableStateOf(existing?.imageUri ?: "") }

    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (existing == null) "Add Project" else "Edit Project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                ImagePickerButton(image) { image = it }
                OutlinedTextField(name, { name = it }, label = { Text("Project name") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Description") })
                OutlinedTextField(link, { link = it }, label = { Text("Project URL (optional)") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
                if (existing != null) TextButton({ vm.deleteProject(existing.id); close() }) { Text("Delete project", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank()) {
                    if (existing == null) vm.addProject(name, description, link, notes, image)
                    else vm.updateProject(existing.copy(name = name, description = description, link = link, notes = notes, imageUri = image))
                    close()
                }
            }) { Text(if (existing == null) "Save" else "Update") }
        },
        dismissButton = { TextButton(close) { Text("Cancel") } }
    )
}

@Composable
private fun ProjectDetailsDialog(project: Project, vm: PortalViewModel, close: () -> Unit) {
    var editing by remember { mutableStateOf(false) }
    val context = LocalContext.current
    if (editing) {
        ProjectEditorDialog(project, vm) { editing = false; close() }
        return
    }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(project.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SavedImage(project.imageUri, 80.dp)
                if (project.description.isNotBlank()) Text(project.description)
                if (project.link.isNotBlank()) {
                    Text(project.link, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(project.link))) } })
                }
                if (project.notes.isNotBlank()) Text("Notes\n${project.notes}")
            }
        },
        confirmButton = { TextButton({ editing = true }) { Text("Edit") } },
        dismissButton = { TextButton({ close() }) { Text("Close") } }
    )
}

@Composable
private fun SettingsScreen(data: PortalData, vm: PortalViewModel) {
    val context = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    var importMessage by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(vm.exportJson().toByteArray(Charsets.UTF_8))
                }
                importMessage = "Backup saved successfully."
            }.onFailure { importMessage = "Could not save backup." }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Empty file")
                if (vm.importJson(raw)) importMessage = "Backup restored successfully."
                else importMessage = "Invalid My Portal backup."
            }.onFailure { importMessage = "Could not restore backup." }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        SettingsRow(Icons.Default.DarkMode, "Dark Theme", "Choose your preferred appearance") {
            Switch(checked = data.darkTheme, onCheckedChange = vm::setDarkTheme)
        }
        SettingsRow(Icons.Default.Storage, "Data & Storage", "${data.links.size} links • ${data.projects.size} projects")
        SettingsRow(Icons.Default.Backup, "Backup", "Export your links and projects") {
            TextButton({ exportLauncher.launch("my-portal-backup.json") }) { Text("Export") }
        }
        SettingsRow(Icons.Default.Restore, "Restore", "Import a My Portal backup") {
            TextButton({ importLauncher.launch(arrayOf("application/json", "text/plain")) }) { Text("Import") }
        }
        SettingsRow(Icons.Default.Security, "Privacy", "Data is stored locally on this device")
        SettingsRow(Icons.Default.Info, "About App", "My Portal • Version 2.0")
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { confirm = true },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.DeleteForever, null); Spacer(Modifier.width(8.dp)); Text("Clear All Data")
        }
    }

    importMessage?.let {
        LaunchedEffect(it) { kotlinx.coroutines.delay(2200); importMessage = null }
        SnackbarHost(remember { SnackbarHostState() })
        ToastMessage(it)
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Clear all data?") },
            text = { Text("Every saved project and link will be removed from this device.") },
            confirmButton = { TextButton({ vm.clearAll(); confirm = false }) { Text("Clear", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    trailing: (@Composable (() -> Unit))? = null
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        leadingContent = { Icon(icon, null) },
        trailingContent = trailing,
        modifier = Modifier.clip(RoundedCornerShape(14.dp))
    )
}

@Composable
private fun ToastMessage(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        Surface(
            modifier = Modifier.padding(bottom = 20.dp),
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 8.dp
        ) { Text(message, Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) }
    }
}
