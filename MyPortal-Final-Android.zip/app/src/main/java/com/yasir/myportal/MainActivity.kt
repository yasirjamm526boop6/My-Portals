package com.yasir.myportal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yasir.myportal.ui.MyPortalApp
import com.yasir.myportal.ui.theme.MyPortalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: PortalViewModel = viewModel()
            MyPortalTheme(darkTheme = vm.data.collectAsStateWithLifecycle().value.darkTheme) {
                MyPortalApp(vm)
            }
        }
    }
}
