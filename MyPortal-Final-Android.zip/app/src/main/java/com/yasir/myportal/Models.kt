package com.yasir.myportal

import kotlinx.serialization.Serializable

@Serializable
data class PortalLink(
    val id: Long,
    val name: String,
    val url: String,
    val category: String = "Other",
    val description: String = "",
    val imageUri: String = ""
)

@Serializable
data class Project(
    val id: Long,
    val name: String,
    val description: String = "",
    val link: String = "",
    val imageUri: String = "",
    val notes: String = ""
)

@Serializable
data class PortalData(
    val links: List<PortalLink> = emptyList(),
    val projects: List<Project> = emptyList(),
    val darkTheme: Boolean = true
)
