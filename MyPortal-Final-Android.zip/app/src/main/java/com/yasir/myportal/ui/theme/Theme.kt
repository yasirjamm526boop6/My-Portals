package com.yasir.myportal.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DA3FF),
    secondary = Color(0xFF20C997),
    tertiary = Color(0xFFFFC857),
    background = Color(0xFF071525),
    surface = Color(0xFF0D223A),
    surfaceVariant = Color(0xFF173553)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF086FE8),
    secondary = Color(0xFF008B68)
)

@Composable
fun MyPortalTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
