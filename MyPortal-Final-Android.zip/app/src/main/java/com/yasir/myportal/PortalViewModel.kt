package com.yasir.myportal

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

private val Context.portalStore by preferencesDataStore("my_portal_store")

class PortalViewModel(app: Application) : AndroidViewModel(app) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val dataKey = stringPreferencesKey("portal_data")

    private val _data = MutableStateFlow(PortalData())
    val data: StateFlow<PortalData> = _data

    init {
        viewModelScope.launch {
            val raw = getApplication<Application>().portalStore.data.first()[dataKey]
            _data.value = raw?.let { runCatching { json.decodeFromString<PortalData>(it) }.getOrNull() }
                ?: PortalData()
        }
    }

    private fun save(value: PortalData) {
        _data.value = value
        viewModelScope.launch {
            getApplication<Application>().portalStore.edit { it[dataKey] = json.encodeToString(value) }
        }
    }

    fun addLink(name: String, url: String, category: String, description: String, imageUri: String) {
        val id = (_data.value.links.maxOfOrNull { it.id } ?: 0L) + 1
        save(_data.value.copy(
            links = _data.value.links + PortalLink(
                id, name.trim(), normalizeUrl(url), category.trim().ifBlank { "Other" },
                description.trim(), imageUri
            )
        ))
    }

    fun updateLink(link: PortalLink) {
        save(_data.value.copy(
            links = _data.value.links.map { if (it.id == link.id) link.copy(url = normalizeUrl(link.url)) else it }
        ))
    }

    fun deleteLink(id: Long) = save(_data.value.copy(links = _data.value.links.filterNot { it.id == id }))

    fun addProject(name: String, description: String, link: String, notes: String, imageUri: String) {
        val id = (_data.value.projects.maxOfOrNull { it.id } ?: 0L) + 1
        save(_data.value.copy(
            projects = _data.value.projects + Project(id, name.trim(), description.trim(), normalizeUrlOptional(link), imageUri, notes.trim())
        ))
    }

    fun updateProject(project: Project) {
        save(_data.value.copy(
            projects = _data.value.projects.map {
                if (it.id == project.id) project.copy(link = normalizeUrlOptional(project.link)) else it
            }
        ))
    }

    fun deleteProject(id: Long) = save(_data.value.copy(projects = _data.value.projects.filterNot { it.id == id }))

    fun setDarkTheme(value: Boolean) = save(_data.value.copy(darkTheme = value))

    fun clearAll() = save(PortalData())

    fun exportJson(): String = json.encodeToString(_data.value)

    fun importJson(raw: String): Boolean {
        val parsed = runCatching { json.decodeFromString<PortalData>(raw) }.getOrNull() ?: return false
        save(parsed)
        return true
    }

    private fun normalizeUrl(value: String): String =
        if (value.trim().startsWith("http://") || value.trim().startsWith("https://")) value.trim()
        else "https://${value.trim()}"

    private fun normalizeUrlOptional(value: String): String =
        if (value.isBlank()) "" else normalizeUrl(value)
}
